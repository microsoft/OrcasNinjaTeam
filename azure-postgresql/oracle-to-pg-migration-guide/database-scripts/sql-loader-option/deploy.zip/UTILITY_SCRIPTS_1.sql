--------------------------------------------------------
--  DDL for Package Body UTILITY_SCRIPTS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "REG_APP"."UTILITY_SCRIPTS" AS
  PROCEDURE create_pg_table_script AS
    
        CURSOR c_tables IS
            SELECT
                table_name
            FROM
                user_tables
            ORDER BY 
                table_name;
            
        r_table c_tables%rowtype;
    BEGIN
            OPEN c_tables;
            LOOP
                FETCH c_tables INTO r_table;
                EXIT WHEN c_tables%notfound;
                -- DBMS_OUTPUT.PUT_LINE( 'if not exist "schema/tables/' || r_table.table_name || '" mkdir "schema/tables/"' || r_table.table_name || '"');
                DBMS_OUTPUT.PUT_LINE( 'ora2pg -t TABLE -a ' || r_table.table_name || ' -o ' || r_table.table_name || '.sql --namespace REG_APP -c config/ora2pg_dist-my-migration-test.conf -b schema/tables/' );
            END LOOP;
            CLOSE c_tables;
    
    
    END create_pg_table_script;
END UTILITY_SCRIPTS;

/
