--------------------------------------------------------
--  Ref Constraints for Table REGISTRATIONS
--------------------------------------------------------

  ALTER TABLE "REG_APP"."REGISTRATIONS" ADD CONSTRAINT "REG_ATTEND_FK" FOREIGN KEY ("ATTENDEE_ID")
	  REFERENCES "REG_APP"."ATTENDEES" ("ID") ENABLE;
  ALTER TABLE "REG_APP"."REGISTRATIONS" ADD CONSTRAINT "REG_SESSION_FK" FOREIGN KEY ("SESSION_ID")
	  REFERENCES "REG_APP"."SESSIONS" ("ID") ENABLE;
