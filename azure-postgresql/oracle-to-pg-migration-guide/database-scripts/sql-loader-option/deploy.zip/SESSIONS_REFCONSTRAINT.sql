--------------------------------------------------------
--  Ref Constraints for Table SESSIONS
--------------------------------------------------------

  ALTER TABLE "REG_APP"."SESSIONS" ADD CONSTRAINT "SESSION_EVENT_FK" FOREIGN KEY ("EVENT_ID")
	  REFERENCES "REG_APP"."EVENTS" ("ID") ENABLE;
  ALTER TABLE "REG_APP"."SESSIONS" ADD CONSTRAINT "SESSION_SPEAKER_FK" FOREIGN KEY ("SPEAKER_ID")
	  REFERENCES "REG_APP"."SPEAKERS" ("ID") ENABLE;
