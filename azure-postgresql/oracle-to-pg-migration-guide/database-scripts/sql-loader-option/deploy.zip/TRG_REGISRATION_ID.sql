--------------------------------------------------------
--  DDL for Trigger TRG_REGISRATION_ID
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "REG_APP"."TRG_REGISRATION_ID" 
  BEFORE INSERT ON REGISTRATIONS
  FOR EACH ROW
BEGIN
  :new.ID := REGISTRATION_ID_SEQ.nextval;
END;
/
ALTER TRIGGER "REG_APP"."TRG_REGISRATION_ID" ENABLE;
