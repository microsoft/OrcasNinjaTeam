--------------------------------------------------------
--  DDL for View V_SPK_SESSION
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "REG_APP"."V_SPK_SESSION" ("SPEAKER_ID", "FIRST_NAME", "LAST_NAME", "SESSION_ID", "SESSION_NAME", "SESSION_DESCRIPTION", "SESSION_DATE", "DURATION", "EVENT_ID") AS 
  select 
    spk.id as speaker_id, 
    spk.first_name,
    spk.last_name, 
    ses.id as session_id, 
    ses.name as session_name, 
    ses.description as session_description, 
    ses.session_date, 
    ses.duration,
    ses.event_id
from speakers spk
    inner join sessions ses
        on ses.speaker_id = spk.id
;
