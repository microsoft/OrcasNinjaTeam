--------------------------------------------------------
--  DDL for Procedure GET_RANDOM_ATTENDEE
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "REG_APP"."GET_RANDOM_ATTENDEE" (p_attendeeid OUT NUMBER) AS
BEGIN
    SELECT
        id into p_attendeeid
    FROM
        (
            SELECT
                id
            FROM
                attendees
            ORDER BY
                dbms_random.value
        )
    WHERE
        ROWNUM = 1;  
END get_random_attendee;

/
