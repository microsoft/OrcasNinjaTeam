--------------------------------------------------------
--  DDL for Procedure REGISTER_ATTENDEE_SESSION
--------------------------------------------------------
set define off;

  CREATE OR REPLACE PROCEDURE "REG_APP"."REGISTER_ATTENDEE_SESSION" 
(
  P_SESSION_ID IN NUMBER 
, P_ATTENDEE_ID IN NUMBER
) AS 
BEGIN

    INSERT INTO registrations (registration_date, session_id, attendee_id) 
    VALUES (SYSDATE, P_SESSION_ID, P_ATTENDEE_ID);
    
    COMMIT;

END REGISTER_ATTENDEE_SESSION;

/
