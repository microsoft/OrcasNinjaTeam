--------------------------------------------------------
--  DDL for Function SESSION_OTHER_INFO_IS_MISSING
--------------------------------------------------------

  CREATE OR REPLACE FUNCTION "REG_APP"."SESSION_OTHER_INFO_IS_MISSING" (
    p_speaker_id IN NUMBER
) RETURN VARCHAR2 AS
    row_count NUMBER;
BEGIN

    SELECT
      COUNT(*) INTO row_count
    FROM
      sessions
    WHERE
      other_info IS NULL
      AND id = p_speaker_id;
          
    IF row_count > 0 THEN
        RETURN 'OTHER INFO IS MISSING';
    ELSE 
        RETURN 'OTHER INFO HAS VALUE';
    END IF;

END session_other_info_is_missing;

/
