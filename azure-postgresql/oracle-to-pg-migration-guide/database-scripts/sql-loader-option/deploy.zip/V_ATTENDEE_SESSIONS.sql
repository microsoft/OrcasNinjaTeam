--------------------------------------------------------
--  DDL for View V_ATTENDEE_SESSIONS
--------------------------------------------------------

  CREATE OR REPLACE FORCE VIEW "REG_APP"."V_ATTENDEE_SESSIONS" ("ATTENDEE_ID", "FIRST_NAME", "LAST_NAME", "SESSION_NAME", "SESSION_START", "DURATION", "REGISTRATION_DATE") AS 
  SELECT
    att.id as attendee_id,
    att.first_name,
    att.last_name,
    ses.name as session_name,
    ses.session_date as session_start,
    ses.duration,
    reg.registration_date
FROM 
    attendees att 
        inner join registrations reg
            on att.id = reg.attendee_id
        inner join sessions ses
            on ses.id = reg.session_id
;
