--------------------------------------------------------
--  DDL for Package UTILITY_SCRIPTS
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "REG_APP"."UTILITY_SCRIPTS" AS 
    PROCEDURE create_pg_table_script;

END UTILITY_SCRIPTS;

/
