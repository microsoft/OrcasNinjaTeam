# HammerDB

HammerDB is the leading benchmarking and load testing software for the worlds most popular databases supporting Oracle Database, Microsoft SQL Server, IBM Db2, PostgreSQL, MySQL and MariaDB.

## Credits

- Steve Shaw
- [All Contributors](https://github.com/TPC-Council/HammerDB/contributors)

## License

GNU General Public License v3.0. Please see [License File](LICENSE) for more information.

## Support

- [Contact information](http://www.hammerdb.com)
- [Documentation](https://www.hammerdb.com/docs)
